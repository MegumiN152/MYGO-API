package com.hh.hhinterface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HhInterfaceApplication {

    public static void main(String[] args) {
        SpringApplication.run(HhInterfaceApplication.class, args);
    }

}
