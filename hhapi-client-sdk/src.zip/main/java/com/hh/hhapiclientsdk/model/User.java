package com.hh.hhapiclientsdk.model;

import lombok.Data;

/**
 * @author 黄昊
 * @version 1.0
 **/
@Data
public class User {
    private String username;
}
